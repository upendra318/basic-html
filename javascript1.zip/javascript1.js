//console.log('Hello');
//document.write('Hello');
function ddd(){
    document.getElementById("aaa").style.fontSize= "30px";
}